package com.vitaltrack.model;

import lombok.Data;

@Data
public class WorkoutType {
  private int workoutId;
  private String workoutName;
  private double metValue;
}
