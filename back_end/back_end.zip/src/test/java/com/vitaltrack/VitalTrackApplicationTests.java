package com.vitaltrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VitalTrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
